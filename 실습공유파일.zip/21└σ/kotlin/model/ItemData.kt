package com.example.ch20_firebase.model

class ItemData {
    var docId: String? = null
    var email: String? = null
    var content: String? = null
    var date: String? = null
}