package com.example.ch18_network.retrofit

import com.example.ch18_network.model.PageListModel
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface NetworkService {

}