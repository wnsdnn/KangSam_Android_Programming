package com.example.ch18_network.model

class ItemModel {

}