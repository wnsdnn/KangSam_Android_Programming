package com.example.ch18_network.model

class PageListModel {

}